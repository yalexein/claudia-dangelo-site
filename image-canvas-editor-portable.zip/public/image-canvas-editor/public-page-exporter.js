(function () {
  const imageCanvasCore = window.ImageCanvasCore || {};
  const visualClickEffects = new Set(["pulse", "pop", "flash", "spin"]);
  const hoverEffects = new Set(["none", "lift", "zoom", "tilt", "glow", "gray-color", "opacity", "paper"]);
  const clickEffects = new Set(["none", "pulse", "pop", "flash", "spin", "open-link", "lock-toggle", "bring-front"]);
  const blendModes = new Set(["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-burn", "color-dodge", "difference", "luminosity"]);
  const motionPresets = new Set(["none", "float", "drift-x", "drift-y", "orbit", "sway", "scroll-left"]);
  const spriteModes = new Set(["forward", "pingpong"]);
  const gradientTypes = new Set(["linear", "radial"]);
  const triggerActions = new Set(["show", "play"]);
  const triggerModes = new Set(["immediate", "delay", "click", "key", "after-layer"]);
  const defaultCanvasBackground = imageCanvasCore.defaultCanvasBackground || {
    baseColor: "#fbfaf7",
    editorGrid: true,
    gradient: {
      enabled: false,
      type: "linear",
      angle: 135,
      stops: [
        { color: "#fbfaf7", position: 0 },
        { color: "#f2b6bf", position: 52 },
        { color: "#b9c7ef", position: 100 },
      ],
    },
    paper: {
      enabled: false,
      strength: 32,
      scale: 1,
    },
  };

  const number = (value, fallback = 0) => {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
  };

  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const normalizeColor = imageCanvasCore.normalizeColor || ((value, fallback = "#fbfaf7") => {
    const raw = String(value || "").trim();
    if (/^#[0-9a-f]{6}$/i.test(raw)) return raw.toLowerCase();
    if (/^#[0-9a-f]{3}$/i.test(raw)) {
      return `#${raw[1]}${raw[1]}${raw[2]}${raw[2]}${raw[3]}${raw[3]}`.toLowerCase();
    }
    return fallback;
  });

  const normalizeBackgroundStop = (stop, fallback) => ({
    color: normalizeColor(stop?.color, fallback.color),
    position: clamp(number(stop?.position, fallback.position), 0, 100),
  });

  const normalizeCanvasBackground = imageCanvasCore.normalizeCanvasBackground || ((value = {}) => {
    const defaults = defaultCanvasBackground;
    const sourceStops = Array.isArray(value?.gradient?.stops) ? value.gradient.stops : [];
    const stops = defaults.gradient.stops.map((fallback, index) => normalizeBackgroundStop(sourceStops[index], fallback));
    return {
      baseColor: normalizeColor(value?.baseColor, defaults.baseColor),
      editorGrid: value?.editorGrid !== false,
      gradient: {
        enabled: value?.gradient?.enabled === true,
        type: gradientTypes.has(String(value?.gradient?.type || "")) ? String(value.gradient.type) : defaults.gradient.type,
        angle: clamp(number(value?.gradient?.angle, defaults.gradient.angle), 0, 360),
        stops,
      },
      paper: {
        enabled: value?.paper?.enabled === true,
        strength: clamp(number(value?.paper?.strength, defaults.paper.strength), 0, 100),
        scale: clamp(number(value?.paper?.scale, defaults.paper.scale), 0.5, 4),
      },
    };
  });

  const gradientCss = (background) => {
    const gradient = background.gradient;
    const stops = gradient.stops
      .slice()
      .sort((first, second) => first.position - second.position)
      .map((stop) => `${stop.color} ${stop.position}%`)
      .join(", ");
    if (gradient.type === "radial") return `radial-gradient(circle at 50% 46%, ${stops})`;
    return `linear-gradient(${gradient.angle}deg, ${stops})`;
  };

  const paperCssLayers = (background) => {
    const strength = clamp(number(background?.paper?.strength, 0), 0, 100) / 100;
    const scale = clamp(number(background?.paper?.scale, 1), 0.5, 4);
    const dark = (0.018 + strength * 0.055).toFixed(3);
    const light = (0.035 + strength * 0.105).toFixed(3);
    const fiber = (0.012 + strength * 0.04).toFixed(3);
    return {
      layers: [
        `repeating-radial-gradient(circle at 18px 24px, rgba(23, 23, 23, ${dark}) 0 0.7px, transparent 1.2px ${Math.round(9 * scale)}px)`,
        `repeating-linear-gradient(96deg, rgba(23, 23, 23, ${fiber}) 0 1px, rgba(255, 255, 255, ${light}) 1px 2px, transparent 2px ${Math.round(13 * scale)}px)`,
        `radial-gradient(circle at 18% 22%, rgba(255, 255, 255, ${light}) 0, transparent 28%), radial-gradient(circle at 78% 68%, rgba(23, 23, 23, ${dark}) 0, transparent 32%)`,
      ],
      sizes: [
        `${Math.round(22 * scale)}px ${Math.round(22 * scale)}px`,
        `${Math.round(96 * scale)}px ${Math.round(96 * scale)}px`,
        "auto, auto",
      ],
    };
  };

  const buildCanvasBackgroundCss = imageCanvasCore.buildCanvasBackgroundCss || ((value = {}, options = {}) => {
    const background = normalizeCanvasBackground(value);
    const layers = [];
    const sizes = [];
    if (options.includeGrid && background.editorGrid) {
      layers.push(
        "linear-gradient(rgba(23, 23, 23, 0.055) 1px, transparent 1px)",
        "linear-gradient(90deg, rgba(23, 23, 23, 0.055) 1px, transparent 1px)",
      );
      sizes.push("40px 40px", "40px 40px");
    }
    if (background.paper.enabled) {
      const paper = paperCssLayers(background);
      layers.push(...paper.layers);
      sizes.push(...paper.sizes);
    }
    if (background.gradient.enabled) {
      layers.push(gradientCss(background));
      sizes.push("auto");
    }
    layers.push(background.baseColor);
    sizes.push("auto");
    return {
      background: layers.join(", "),
      size: sizes.join(", "),
    };
  });

  const normalizeTrim = (item) => {
    const naturalWidth = Math.max(number(item?.trim?.naturalWidth, number(item?.naturalWidth, number(item?.width, 320))), 1);
    const naturalHeight = Math.max(number(item?.trim?.naturalHeight, number(item?.naturalHeight, naturalWidth * 0.75)), 1);
    const x = clamp(number(item?.trim?.x, 0), 0, naturalWidth);
    const y = clamp(number(item?.trim?.y, 0), 0, naturalHeight);
    const width = clamp(number(item?.trim?.width, naturalWidth - x), 1, naturalWidth - x);
    const height = clamp(number(item?.trim?.height, naturalHeight - y), 1, naturalHeight - y);
    return { naturalWidth, naturalHeight, x, y, width, height };
  };

  const normalizeMotion = (value) => ({
    preset: motionPresets.has(value?.preset) ? value.preset : "none",
    speed: clamp(number(value?.speed, 1), 0.05, 5),
    distance: clamp(number(value?.distance, 40), 0, 400),
  });

  const normalizeParallax = (value) => ({
    enabled: value?.enabled === true,
    depth: clamp(number(value?.depth, 1), 0, 2.5),
  });

  const normalizePath = (value) => ({
    enabled: value?.enabled === true,
    duration: clamp(number(value?.duration, 6), 1, 30),
    points: Array.isArray(value?.points)
      ? value.points.map((point) => ({ x: number(point?.x, 0), y: number(point?.y, 0) })).slice(0, 12)
      : [],
  });

  const normalizePublicDrag = (value) => ({
    enabled: value?.enabled === true,
    inertia: clamp(number(value?.inertia, 0.88), 0, 0.98),
  });

  const normalizeTrigger = imageCanvasCore.normalizeLayerTrigger || ((value) => ({
    action: triggerActions.has(String(value?.action || "")) ? String(value.action) : "show",
    mode: triggerModes.has(String(value?.mode || "")) ? String(value.mode) : "immediate",
    delay: clamp(number(value?.delay, 0), 0, 30),
    key: String(value?.key || "Space").trim() || "Space",
    targetId: String(value?.targetId || "").trim(),
  }));

  const normalizeSpriteFrame = (frame, index = 0) => ({
    src: String(typeof frame === "string" ? frame : frame?.src || ""),
    name: String(frame?.name || `frame-${index + 1}`).trim() || `frame-${index + 1}`,
  });

  const normalizeSprite = (value, fallbackSrc = "") => {
    const frames = Array.isArray(value?.frames)
      ? value.frames.map(normalizeSpriteFrame).filter((frame) => frame.src)
      : [];
    if (!frames.length && fallbackSrc) frames.push({ src: String(fallbackSrc), name: "frame-1" });
    return {
      enabled: value?.enabled === true && frames.length > 0,
      name: String(value?.name || "idle").trim() || "idle",
      frames,
      fps: clamp(number(value?.fps, 8), 1, 30),
      loop: value?.loop !== false,
      mode: spriteModes.has(String(value?.mode || "")) ? String(value.mode) : "forward",
      playing: value?.playing !== false,
      frameIndex: clamp(Math.round(number(value?.frameIndex, 0)), 0, Math.max(frames.length - 1, 0)),
      anchor: String(value?.anchor || "bottom-center"),
      syncMotion: value?.syncMotion === true,
    };
  };

  const normalizeItem = (item, index) => ({
    id: String(item?.id || `public-image-${index}`),
    src: String(item?.src || ""),
    x: number(item?.x, 120),
    y: number(item?.y, 140),
    width: clamp(number(item?.width, number(item?.w, 320)), 1, 4000),
    rotation: number(item?.rotation, number(item?.rotate, 0)),
    z: clamp(number(item?.z, 20), 0, 10000),
    opacity: imageCanvasCore.normalizeOpacity ? imageCanvasCore.normalizeOpacity(item?.opacity, 1) : clamp(number(item?.opacity, 1), 0, 1),
    blendMode: imageCanvasCore.normalizeBlendMode ? imageCanvasCore.normalizeBlendMode(item?.blendMode, "normal") : (blendModes.has(item?.blendMode) ? item.blendMode : "normal"),
    hoverEffect: imageCanvasCore.normalizeHoverEffect ? imageCanvasCore.normalizeHoverEffect(item?.hoverEffect, "none") : (hoverEffects.has(item?.hoverEffect) ? item.hoverEffect : "none"),
    clickEffect: imageCanvasCore.normalizeClickEffect ? imageCanvasCore.normalizeClickEffect(item?.clickEffect, "none") : (clickEffects.has(item?.clickEffect) ? item.clickEffect : "none"),
    linkUrl: imageCanvasCore.normalizeLink ? imageCanvasCore.normalizeLink(item?.linkUrl) : String(item?.linkUrl || "").trim(),
    trim: normalizeTrim(item),
    hidden: item?.hidden === true,
    locked: item?.locked === true,
    motion: normalizeMotion(item?.motion),
    parallax: normalizeParallax(item?.parallax),
    publicDrag: normalizePublicDrag(item?.publicDrag),
    trigger: normalizeTrigger(item?.trigger),
    sprite: normalizeSprite(item?.sprite, item?.src),
    pathMotion: normalizePath(item?.pathMotion),
  });

  const htmlEscape = (value) =>
    String(value).replace(/[&<>"']/g, (char) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    })[char]);

  const scriptJson = (value) =>
    JSON.stringify(value).replace(/</g, "\\u003c").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");

  const estimateHeight = (items) =>
    Math.max(900, Math.ceil(items.reduce((max, item) => {
      const scale = item.width / Math.max(item.trim.naturalWidth, 1);
      return Math.max(max, item.y + item.trim.naturalHeight * scale + 220);
    }, 0)));

  const runtimeScript = function () {
    const visualClickEffects = new Set(["pulse", "pop", "flash", "spin"]);
    const motionPresets = new Set(["none", "float", "drift-x", "drift-y", "orbit", "sway", "scroll-left"]);
    const number = (value, fallback = 0) => {
      const parsed = Number(value);
      return Number.isFinite(parsed) ? parsed : fallback;
    };
    const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
    const canvas = document.querySelector("[data-public-canvas]");
    const rawData = document.getElementById("canvas-data");
    const items = rawData ? JSON.parse(rawData.textContent || "[]") : [];
    const boxes = new Map();
    const masks = new Map();
    const dragOffsets = new Map();
    const inertiaItems = new Map();
    const clickSuppressions = new Map();
    const spriteRuntimeStarts = new Map();
    const spriteMotionRuntime = new Map();
    const triggerRuntime = new Map();
    const triggerTimers = new Map();
    let hoverId = "";
    let raf = 0;
    let inertiaRaf = 0;
    const camera = { x: 0, y: 0 };

    const resolveLink = (value) => {
      const raw = String(value || "").trim();
      if (!raw) return "";
      if (raw.startsWith("#")) return window.location.pathname + raw;
      if (/^[a-z][a-z0-9+.-]*:/i.test(raw)) return raw;
      const path = raw.startsWith("/") ? raw : "/" + raw.replace(/^\/+/, "");
      return new URL(path, window.location.origin).href;
    };

    const motionActive = (motion) => motion && motion.preset !== "none" && motion.speed > 0 && motion.distance > 0;
    const parallaxActive = (parallax) => parallax && parallax.enabled && parallax.depth > 0;
    const pathActive = (item) => item.pathMotion && item.pathMotion.enabled && item.pathMotion.points.length > 1;
    const publicDragActive = (item) => item.publicDrag && item.publicDrag.enabled && item.locked !== true && item.hidden !== true;
    const dragOffset = (id) => dragOffsets.get(String(id || "")) || { x: 0, y: 0 };
    const spriteActive = (item) => item.sprite && item.sprite.enabled && item.sprite.frames && item.sprite.frames.length;
    const triggerInitiallyActive = (item) => item.trigger?.mode === "immediate";
    const triggered = (item) => triggerRuntime.get(item.id)?.active === true;
    const layerVisible = (item) => item.trigger?.action !== "show" || triggered(item);
    const animationAllowed = (item) => item.trigger?.action !== "play" || triggered(item);
    const spriteAnimating = (item) => spriteActive(item) && animationAllowed(item) && (item.sprite.syncMotion || item.sprite.playing) && item.sprite.frames.length > 1 && item.sprite.fps > 0;
    const setTriggered = (id, active = true) => {
      if (!id) return;
      triggerRuntime.set(id, { active, startedAt: window.performance.now() });
      const item = items.find((entry) => entry.id === id);
      const box = boxes.get(id);
      if (item && box) box.classList.toggle("is-trigger-hidden", !layerVisible(item));
      spriteRuntimeStarts.delete(id);
      spriteMotionRuntime.delete(id);
      items.forEach((entry) => {
        if (entry.trigger?.mode === "after-layer" && entry.trigger.targetId === id) setTriggered(entry.id, true);
      });
      syncMotion();
    };
    const resetTriggers = () => {
      triggerTimers.forEach((timer) => window.clearTimeout(timer));
      triggerTimers.clear();
      triggerRuntime.clear();
      items.forEach((item) => {
        triggerRuntime.set(item.id, { active: triggerInitiallyActive(item), startedAt: window.performance.now() });
        if (item.trigger?.mode === "delay") {
          triggerTimers.set(item.id, window.setTimeout(() => setTriggered(item.id, true), item.trigger.delay * 1000));
        }
      });
      items.forEach((item) => {
        if (item.trigger?.mode === "after-layer") {
          const target = items.find((entry) => entry.id === item.trigger.targetId);
          if (target && triggered(target)) setTriggered(item.id, true);
        }
      });
    };

    const spriteFrameIndex = (item, time) => {
      if (!spriteActive(item)) return 0;
      const sprite = item.sprite;
      const count = sprite.frames.length;
      if (sprite.syncMotion && count > 1) {
        const index = items.findIndex((entry) => entry.id === item.id);
        const state = getRenderState(item, Math.max(index, 0), time);
        const x = number(item.x) + state.x;
        const y = number(item.y) + state.y;
        const distancePerFrame = Math.max(number(item.width, 180) / 7, 12);
        const runtime = spriteMotionRuntime.get(item.id) || { x, y, distance: number(sprite.frameIndex, 0) * distancePerFrame };
        const delta = Math.hypot(x - runtime.x, y - runtime.y);
        if (delta > 0.05) runtime.distance += delta;
        runtime.x = x;
        runtime.y = y;
        spriteMotionRuntime.set(item.id, runtime);
        const step = Math.floor(runtime.distance / distancePerFrame);
        if (!sprite.loop) return clamp(step, 0, count - 1);
        if (sprite.mode === "pingpong" && count > 1) {
          const cycle = count * 2 - 2;
          const frame = step % cycle;
          return frame < count ? frame : cycle - frame;
        }
        return step % count;
      }
      if (!sprite.playing || count <= 1) return clamp(number(sprite.frameIndex, 0), 0, count - 1);
      if (!spriteRuntimeStarts.has(item.id)) spriteRuntimeStarts.set(item.id, time - (number(sprite.frameIndex, 0) / sprite.fps) * 1000);
      const elapsed = Math.max(0, (time - spriteRuntimeStarts.get(item.id)) / 1000);
      const step = Math.floor(elapsed * sprite.fps);
      if (!sprite.loop) return clamp(step, 0, count - 1);
      if (sprite.mode === "pingpong" && count > 1) {
        const cycle = count * 2 - 2;
        const frame = step % cycle;
        return frame < count ? frame : cycle - frame;
      }
      return step % count;
    };

    const currentSpriteFrame = (item, time) => {
      if (!spriteActive(item)) return { src: item.src || "", name: "frame-1" };
      return item.sprite.frames[spriteFrameIndex(item, time)] || item.sprite.frames[0];
    };

    const applySpriteFrame = (item, time) => {
      if (!spriteActive(item)) return;
      const box = boxes.get(item.id);
      const image = box ? box.querySelector("img") : null;
      if (!(image instanceof HTMLImageElement)) return;
      const frame = currentSpriteFrame(item, time);
      if (frame.src && image.src !== frame.src) {
        image.addEventListener("load", () => buildMask(item, image), { once: true });
        image.src = frame.src;
      }
    };

    const getMotionState = (item, index, time) => {
      if (!animationAllowed(item)) return { x: 0, y: 0, rotation: 0 };
      const motion = item.motion || { preset: "none", speed: 1, distance: 40 };
      if (!motionPresets.has(motion.preset) || !motionActive(motion)) return { x: 0, y: 0, rotation: 0 };
      const phase = ((time / 1000) * motion.speed + index * 0.137) * Math.PI * 2;
      const distance = motion.distance;
      if (motion.preset === "float") return { x: 0, y: Math.sin(phase) * distance, rotation: 0 };
      if (motion.preset === "drift-x") return { x: Math.sin(phase) * distance, y: 0, rotation: 0 };
      if (motion.preset === "drift-y") return { x: 0, y: Math.sin(phase) * distance, rotation: 0 };
      if (motion.preset === "orbit") return { x: Math.cos(phase) * distance, y: Math.sin(phase) * distance * 0.55, rotation: 0 };
      if (motion.preset === "sway") return { x: 0, y: 0, rotation: Math.sin(phase) * Math.min(24, distance / 4) };
      if (motion.preset === "scroll-left") {
        const span = Math.max(distance * 2, 1);
        const progress = ((time / 1000) * motion.speed * 80 + index * 47) % span;
        return { x: distance - progress, y: 0, rotation: 0 };
      }
      return { x: 0, y: 0, rotation: 0 };
    };

    const getPathState = (item, time) => {
      if (!animationAllowed(item)) return { x: 0, y: 0 };
      if (!pathActive(item)) return { x: 0, y: 0 };
      const points = item.pathMotion.points;
      const legCount = points.length - 1;
      const cycleLegs = legCount * 2;
      const progress = ((time / 1000) % item.pathMotion.duration) / item.pathMotion.duration;
      const mirroredProgress = progress * cycleLegs;
      const pathProgress = mirroredProgress <= legCount ? mirroredProgress : cycleLegs - mirroredProgress;
      const legIndex = clamp(Math.floor(pathProgress), 0, legCount - 1);
      const localProgress = pathProgress - legIndex;
      const easedProgress = localProgress * localProgress * (3 - 2 * localProgress);
      const startPoint = points[legIndex];
      const endPoint = points[legIndex + 1];
      return {
        x: startPoint.x + (endPoint.x - startPoint.x) * easedProgress - number(item.x),
        y: startPoint.y + (endPoint.y - startPoint.y) * easedProgress - number(item.y),
      };
    };

    const getRenderState = (item, index, time) => {
      const motion = getMotionState(item, index, time);
      const path = getPathState(item, time);
      const parallax = item.parallax || { enabled: false, depth: 1 };
      const offset = dragOffset(item.id);
      return {
        x: motion.x + path.x + (parallaxActive(parallax) ? -camera.x * parallax.depth : 0) + offset.x,
        y: motion.y + path.y + (parallaxActive(parallax) ? -camera.y * parallax.depth : 0) + offset.y,
        rotation: motion.rotation,
      };
    };

    const applyTransform = (item, index, time) => {
      const box = boxes.get(item.id);
      if (!box) return;
      const state = getRenderState(item, index, time);
      box.style.transform = "translate(" + (item.x + state.x) + "px, " + (item.y + state.y) + "px) rotate(" + (item.rotation + state.rotation) + "deg)";
    };

    const syncMotion = () => {
      const hasMotion = items.some((item) => motionActive(item.motion) || pathActive(item) || parallaxActive(item.parallax) || spriteAnimating(item) || inertiaItems.size);
      if (!hasMotion) {
        raf = 0;
        return;
      }
      if (raf) return;
      const tick = (time) => {
        raf = 0;
        items.forEach((item, index) => {
          applyTransform(item, index, time);
          applySpriteFrame(item, time);
        });
        syncMotion();
      };
      raf = window.requestAnimationFrame(tick);
    };

    const buildMask = (item, image) => {
      try {
        const width = image.naturalWidth || item.trim.naturalWidth;
        const height = image.naturalHeight || item.trim.naturalHeight;
        if (!width || !height) return;
        const c = document.createElement("canvas");
        c.width = width;
        c.height = height;
        const ctx = c.getContext("2d", { willReadFrequently: true });
        ctx.drawImage(image, 0, 0);
        masks.set(item.id, { naturalWidth: width, naturalHeight: height, alpha: ctx.getImageData(0, 0, width, height).data });
      } catch {
        masks.delete(item.id);
      }
    };

    const render = () => {
      canvas.innerHTML = "";
      items.forEach((item, index) => {
        if (item.hidden || !item.src) return;
        const trim = item.trim;
        const scale = item.width / Math.max(trim.naturalWidth, 1);
        const fullHeight = trim.naturalHeight * scale;
        const trimLeft = trim.x * scale;
        const trimTop = trim.y * scale;
        const trimWidth = trim.width * scale;
        const trimHeight = trim.height * scale;
        const box = document.createElement("figure");
        box.className = "public-image";
        box.dataset.id = item.id;
        box.dataset.hoverEffect = item.hoverEffect;
        box.dataset.clickEffect = item.clickEffect;
        box.dataset.hasLink = resolveLink(item.linkUrl) ? "true" : "false";
        box.dataset.publicDrag = publicDragActive(item) ? "true" : "false";
        box.classList.toggle("is-trigger-hidden", !layerVisible(item));
        box.style.width = item.width + "px";
        box.style.height = fullHeight + "px";
        box.style.zIndex = String(item.z);
        box.style.setProperty("--image-opacity", String(item.opacity));
        box.style.setProperty("--blend-mode", item.blendMode);
        box.style.setProperty("--image-full-width", item.width + "px");
        box.style.setProperty("--image-full-height", fullHeight + "px");
        box.style.setProperty("--trim-left", trimLeft + "px");
        box.style.setProperty("--trim-top", trimTop + "px");
        box.style.setProperty("--trim-width", trimWidth + "px");
        box.style.setProperty("--trim-height", trimHeight + "px");
        const surface = document.createElement("div");
        surface.className = "public-image__surface";
        const image = document.createElement("img");
        const frame = spriteActive(item) ? currentSpriteFrame(item, window.performance.now()) : null;
        image.src = frame && frame.src ? frame.src : item.src;
        image.alt = "Immagine";
        image.draggable = false;
        image.addEventListener("load", () => buildMask(item, image), { once: true });
        surface.append(image);
        box.append(surface);
        boxes.set(item.id, box);
        canvas.append(box);
        applyTransform(item, index, window.performance.now());
      });
      syncMotion();
    };

    const hitForItem = (item, index, pageX, pageY) => {
      if (item.hidden || !layerVisible(item) || item.opacity <= 0.01) return null;
      const state = getRenderState(item, index, window.performance.now());
      const trim = item.trim;
      const scale = item.width / Math.max(trim.naturalWidth, 1);
      const fullHeight = trim.naturalHeight * scale;
      const centerX = item.width / 2;
      const centerY = fullHeight / 2;
      const dx = pageX - item.x - state.x;
      const dy = pageY - item.y - state.y;
      const radians = -(item.rotation + state.rotation) * Math.PI / 180;
      const cos = Math.cos(radians);
      const sin = Math.sin(radians);
      const relX = dx - centerX;
      const relY = dy - centerY;
      const localX = relX * cos - relY * sin + centerX;
      const localY = relX * sin + relY * cos + centerY;
      const trimLeft = trim.x * scale;
      const trimTop = trim.y * scale;
      const trimWidth = trim.width * scale;
      const trimHeight = trim.height * scale;
      if (localX < trimLeft || localY < trimTop || localX > trimLeft + trimWidth || localY > trimTop + trimHeight) return null;
      const mask = masks.get(item.id);
      if (mask) {
        const naturalX = Math.floor(localX / Math.max(scale, 0.0001));
        const naturalY = Math.floor(localY / Math.max(scale, 0.0001));
        const alphaIndex = (naturalY * mask.naturalWidth + naturalX) * 4 + 3;
        if (naturalX >= 0 && naturalY >= 0 && naturalX < mask.naturalWidth && naturalY < mask.naturalHeight && mask.alpha[alphaIndex] <= 8) return null;
      }
      return { item, index, localX, localY, trimLeft, trimTop, trimWidth, trimHeight };
    };

    const getHit = (event) => {
      const pageX = event.pageX || event.clientX + window.scrollX;
      const pageY = event.pageY || event.clientY + window.scrollY;
      const ordered = items.map((item, index) => ({ item, index })).sort((a, b) => b.item.z - a.item.z || b.index - a.index);
      for (const entry of ordered) {
        const hit = hitForItem(entry.item, entry.index, pageX, pageY);
        if (hit) return hit;
      }
      return null;
    };

    const clearHover = () => {
      if (hoverId && boxes.get(hoverId)) boxes.get(hoverId).classList.remove("is-shape-hover");
      hoverId = "";
      document.body.style.cursor = "";
    };

    const setHover = (hit) => {
      if (!hit) return clearHover();
      if (hoverId && hoverId !== hit.item.id && boxes.get(hoverId)) boxes.get(hoverId).classList.remove("is-shape-hover");
      const box = boxes.get(hit.item.id);
      if (!box) return clearHover();
      hoverId = hit.item.id;
      box.classList.add("is-shape-hover");
      document.body.style.cursor = publicDragActive(hit.item) ? "grab" : resolveLink(hit.item.linkUrl) ? "pointer" : "";
      if (hit.item.hoverEffect === "tilt") {
        const x = ((hit.localX - hit.trimLeft) / Math.max(hit.trimWidth, 1) - 0.5) * 2;
        const y = ((hit.localY - hit.trimTop) / Math.max(hit.trimHeight, 1) - 0.5) * 2;
        box.style.setProperty("--tilt-x", clamp(-y * 8, -8, 8) + "deg");
        box.style.setProperty("--tilt-y", clamp(x * 10, -10, 10) + "deg");
      }
    };

    const triggerAnimation = (item) => {
      const box = boxes.get(item.id);
      if (!box) return;
      box.classList.remove("is-click-pulse", "is-click-pop", "is-click-flash", "is-click-spin");
      window.requestAnimationFrame(() => {
        void box.offsetWidth;
        box.classList.add("is-click-" + item.clickEffect);
        box.addEventListener("animationend", () => {
          box.classList.remove("is-click-pulse", "is-click-pop", "is-click-flash", "is-click-spin");
        }, { once: true });
      });
    };

    const activate = (item) => {
      const href = resolveLink(item.linkUrl);
      const visual = visualClickEffects.has(item.clickEffect);
      if (visual) triggerAnimation(item);
      if (item.clickEffect === "bring-front") {
        item.z = Math.max(...items.map((entry) => entry.z)) + 5;
        const box = boxes.get(item.id);
        if (box) box.style.zIndex = String(item.z);
      }
      if (href) {
        window.setTimeout(() => {
          window.location.href = href;
        }, visual ? 360 : 0);
      }
    };

    const clickSuppressed = (id) => {
      const now = Date.now();
      return now - number(clickSuppressions.get(String(id)), 0) < 450 || now - number(clickSuppressions.get("__global"), 0) < 280;
    };

    const markClickSuppressed = (id) => {
      const now = Date.now();
      clickSuppressions.set(String(id), now);
      clickSuppressions.set("__global", now);
    };

    const syncInertia = () => {
      if (!inertiaItems.size || inertiaRaf) return;
      const tick = (time) => {
        inertiaRaf = 0;
        inertiaItems.forEach((state, id) => {
          const item = items.find((entry) => entry.id === id);
          if (!item || !publicDragActive(item)) {
            inertiaItems.delete(id);
            return;
          }
          const elapsed = Math.max((time - number(state.time, time)) / 1000, 0);
          const dt = clamp(elapsed, 0.001, 0.032);
          const offset = dragOffset(id);
          dragOffsets.set(id, { x: offset.x + state.vx * dt, y: offset.y + state.vy * dt });
          const damping = Math.pow(item.publicDrag.inertia, Math.min(elapsed, 0.12) * 60);
          state.vx *= damping;
          state.vy *= damping;
          state.time = time;
          if (Math.hypot(state.vx, state.vy) < 8 || item.publicDrag.inertia <= 0.01) inertiaItems.delete(id);
        });
        items.forEach((item, index) => applyTransform(item, index, time));
        if (inertiaItems.size) inertiaRaf = window.requestAnimationFrame(tick);
      };
      inertiaRaf = window.requestAnimationFrame(tick);
    };

    const startPublicDrag = (event, hit) => {
      if (!publicDragActive(hit.item)) return false;
      event.preventDefault();
      const item = hit.item;
      const id = item.id;
      inertiaItems.delete(id);
      const startOffset = dragOffset(id);
      const startX = event.pageX;
      const startY = event.pageY;
      let lastX = event.pageX;
      let lastY = event.pageY;
      let lastTime = window.performance.now();
      let velocityX = 0;
      let velocityY = 0;
      let moved = false;
      document.body.style.cursor = "grabbing";
      const move = (moveEvent) => {
        const now = window.performance.now();
        const deltaX = moveEvent.pageX - startX;
        const deltaY = moveEvent.pageY - startY;
        moved = moved || Math.hypot(deltaX, deltaY) > 5;
        const dt = clamp((now - lastTime) / 1000, 0.001, 0.08);
        const instantVelocityX = (moveEvent.pageX - lastX) / dt;
        const instantVelocityY = (moveEvent.pageY - lastY) / dt;
        velocityX = velocityX * 0.35 + instantVelocityX * 0.65;
        velocityY = velocityY * 0.35 + instantVelocityY * 0.65;
        dragOffsets.set(id, { x: startOffset.x + deltaX, y: startOffset.y + deltaY });
        lastX = moveEvent.pageX;
        lastY = moveEvent.pageY;
        lastTime = now;
        applyTransform(item, hit.index, now);
      };
      const up = () => {
        document.removeEventListener("pointermove", move);
        document.removeEventListener("pointerup", up);
        document.body.style.cursor = "";
        if (!moved) return;
        markClickSuppressed(id);
        const releaseNow = window.performance.now();
        const releaseGap = Math.max(releaseNow - lastTime, 0);
        const staleFactor = releaseGap > 80 ? clamp(1 - (releaseGap - 80) / 180, 0, 1) : 1;
        const handoffVelocityX = clamp(velocityX * staleFactor, -2400, 2400);
        const handoffVelocityY = clamp(velocityY * staleFactor, -2400, 2400);
        if (Math.hypot(handoffVelocityX, handoffVelocityY) > 12 && item.publicDrag.inertia > 0.01) {
          inertiaItems.set(id, { vx: handoffVelocityX, vy: handoffVelocityY, time: releaseNow - 16 });
          syncInertia();
        }
      };
      document.addEventListener("pointermove", move);
      document.addEventListener("pointerup", up, { once: true });
      return true;
    };

    document.addEventListener("pointermove", (event) => {
      camera.x = ((event.clientX / Math.max(window.innerWidth, 1)) - 0.5) * 80;
      camera.y = ((event.clientY / Math.max(window.innerHeight, 1)) - 0.5) * 80;
      setHover(getHit(event));
      if (items.some((item) => parallaxActive(item.parallax))) syncMotion();
    });

    document.addEventListener("pointerdown", (event) => {
      if (event.button !== 0) return;
      const hit = getHit(event);
      if (hit) startPublicDrag(event, hit);
    });

    document.addEventListener("click", (event) => {
      const hit = getHit(event);
      if (!hit || clickSuppressed(hit.item.id)) return;
      event.preventDefault();
      if (hit.item.trigger?.mode === "click") setTriggered(hit.item.id, true);
      activate(hit.item);
    }, true);

    document.addEventListener("keydown", (event) => {
      const pressedTriggerKey = event.key === " " ? "Space" : event.key;
      const matchingTriggerItems = items.filter((item) => item.trigger?.mode === "key" && item.trigger.key.toLowerCase() === pressedTriggerKey.toLowerCase());
      if (matchingTriggerItems.length) {
        event.preventDefault();
        matchingTriggerItems.forEach((item) => setTriggered(item.id, true));
        return;
      }
      if (event.key !== "Enter" && event.key !== " ") return;
      const hit = hoverId ? { item: items.find((item) => item.id === hoverId) } : null;
      if (!hit || !hit.item) return;
      event.preventDefault();
      activate(hit.item);
    });

    resetTriggers();
    render();
  };

  const runtimeSource = `(${runtimeScript.toString()})();`;

  window.createImageCanvasPublicHtml = (sourceItems, options = {}) => {
    const items = (Array.isArray(sourceItems) ? sourceItems : [])
      .map(normalizeItem)
      .filter((item) => item.src && !item.hidden);
    const title = options.title || "Canvas immagini";
    const minHeight = estimateHeight(items);
    const backgroundCss = buildCanvasBackgroundCss(options.background, { includeGrid: false });
    return `<!doctype html>
<html lang="it">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${htmlEscape(title)}</title>
  <style>
    * { box-sizing: border-box; }
    html, body { min-height: 100%; margin: 0; }
    body {
      min-height: ${minHeight}px;
      overflow-x: hidden;
      background: ${backgroundCss.background};
      background-size: ${backgroundCss.size};
      color: #171717;
      font-family: Inter, "Avenir Next", "Helvetica Neue", Arial, sans-serif;
    }
    .public-stage { position: relative; min-height: ${minHeight}px; }
    .public-canvas { position: absolute; inset: 0; min-height: ${minHeight}px; }
    .public-image {
      --tilt-x: 0deg;
      --tilt-y: 0deg;
      --image-opacity: 1;
      --blend-mode: normal;
      --image-full-width: 100%;
      --image-full-height: auto;
      --trim-left: 0px;
      --trim-top: 0px;
      --trim-width: 100%;
      --trim-height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      margin: 0;
      filter: drop-shadow(0 18px 28px rgba(23, 23, 23, 0.14));
      mix-blend-mode: var(--blend-mode);
      pointer-events: none;
      user-select: none;
      touch-action: none;
    }
    .public-image.is-trigger-hidden {
      opacity: 0;
      pointer-events: none;
    }
    .public-image__surface {
      position: absolute;
      top: var(--trim-top);
      left: var(--trim-left);
      display: block;
      width: var(--trim-width);
      height: var(--trim-height);
      opacity: var(--image-opacity);
      pointer-events: none;
      transform-origin: center;
      transition: filter 180ms ease, opacity 180ms ease, transform 180ms ease;
      will-change: filter, opacity, transform;
    }
    .public-image__surface img {
      position: absolute;
      top: calc(-1 * var(--trim-top));
      left: calc(-1 * var(--trim-left));
      display: block;
      width: var(--image-full-width);
      max-width: none;
      height: auto;
      pointer-events: none;
      user-select: none;
      -webkit-user-drag: none;
    }
    .public-image[data-hover-effect="lift"].is-shape-hover .public-image__surface { transform: translateY(-10px) scale(1.02); }
    .public-image[data-hover-effect="zoom"].is-shape-hover .public-image__surface { transform: scale(1.08); }
    .public-image[data-hover-effect="tilt"].is-shape-hover .public-image__surface { transform: perspective(760px) rotateX(var(--tilt-x)) rotateY(var(--tilt-y)) scale(1.03); }
    .public-image[data-hover-effect="glow"].is-shape-hover .public-image__surface { filter: drop-shadow(0 0 22px rgba(242, 182, 191, 0.86)); }
    .public-image[data-hover-effect="gray-color"] img { filter: grayscale(1); transition: filter 180ms ease; }
    .public-image[data-hover-effect="gray-color"].is-shape-hover img { filter: grayscale(0); }
    .public-image[data-hover-effect="opacity"] .public-image__surface { opacity: calc(var(--image-opacity) * 0.58); }
    .public-image[data-hover-effect="opacity"].is-shape-hover .public-image__surface { opacity: var(--image-opacity); }
    .public-image[data-hover-effect="paper"].is-shape-hover .public-image__surface { animation: paper-wobble 680ms ease-in-out infinite alternate; }
    .public-image.is-click-pulse .public-image__surface { animation: click-pulse 360ms ease-out; }
    .public-image.is-click-pop .public-image__surface { animation: click-pop 420ms cubic-bezier(.2, 1.3, .3, 1); }
    .public-image.is-click-spin .public-image__surface { animation: click-spin 520ms ease-in-out; }
    .public-image.is-click-flash::before {
      content: "";
      position: absolute;
      inset: -12px;
      z-index: 1;
      border: 2px solid rgba(255, 255, 255, 0.92);
      border-radius: 10px;
      pointer-events: none;
      animation: click-flash 520ms ease-out;
    }
    @keyframes paper-wobble { from { transform: rotate(-1.4deg) translateY(-4px); } to { transform: rotate(1.4deg) translateY(-8px); } }
    @keyframes click-pulse { 0% { transform: scale(1); } 42% { transform: scale(1.075); } 100% { transform: scale(1); } }
    @keyframes click-pop { 0% { transform: scale(1); } 42% { transform: scale(1.13) rotate(-1deg); } 100% { transform: scale(1) rotate(0deg); } }
    @keyframes click-spin { 0% { transform: rotate(0deg) scale(1); } 100% { transform: rotate(360deg) scale(1); } }
    @keyframes click-flash { 0% { opacity: 0; transform: scale(0.95); } 34% { opacity: 1; transform: scale(1.04); } 100% { opacity: 0; transform: scale(1.16); } }
  </style>
</head>
<body>
  <main class="public-stage" aria-label="${htmlEscape(title)}">
    <div class="public-canvas" data-public-canvas></div>
  </main>
  <script type="application/json" id="canvas-data">${scriptJson(items)}</script>
  <script>${runtimeSource.replace(/<\/script/gi, "<\\/script")}<\/script>
</body>
</html>
`;
  };

  window.downloadImageCanvasPublicHtml = (sourceItems, options = {}) => {
    const html = window.createImageCanvasPublicHtml(sourceItems, options);
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = options.filename || "canvas-immagini-pubblica.html";
    document.body.append(link);
    link.click();
    URL.revokeObjectURL(link.href);
    link.remove();
  };
})();
